const Colors = {
  white: '#FFF',
  background: '#FFFFFF',
  primary: '#FF2156',
  text: '#272A2F',
  lightGrey: '#E8E8E8',
  grey: '#C0C0C0',
  darkGrey: '#7E7E7E',
  green: '#689593',
};
export default Colors;
