const Images = {
  logoSmall: require('./logoSmall.png'),
  logoLarge: require('./logoLarge.png'),
  success: require('./success.png'),
};

export default Images;
