import {View, Text} from 'react-native';
import React, {useState} from 'react';
import AppBackground from '../../components/AppBackground';
import CustomTextInput from '../../components/CustomTextInput';
import Icons from '../../assets/Icons';
import CustomButton from '../../components/CustomButton';
import bloodGroups from '../../config/Utils/bloodGroups';
import Geolocation from '@react-native-community/geolocation';
import hasLocationPermission from '../../config/Utils/permissions';
import TextWithActionSheet from '../../components/TextWithActionSheet';
import cities from '../../config/Utils/cities';
import {requestDonation} from '../../redux/apis';
import {useSelector} from 'react-redux';
import {useEffect} from 'react';

const RequestBlood = () => {
  const userData = useSelector(state => state.user.userData);
  const [city, setCity] = useState('');
  const [hospital, setHospital] = useState('');
  const [bloodGroup, setBloodGroup] = useState('');
  const [mobile, setMobile] = useState('+92');
  const [note, setNote] = useState('');
  const [latitude, setLatitude] = useState(null);
  const [longitude, setLongitude] = useState(null);
  

  const getCurrentLocation = () => {
    Geolocation.getCurrentPosition(
      position => {
        setLatitude(position.coords.latitude);
        setLongitude(position.coords.longitude);
      },
      error => {
        console.log(error);
      },
      { enableHighAccuracy: true, timeout: 15000, maximumAge: 10000 }
    );
  };

  useEffect(() => {
    getCurrentLocation();
  }, []);


  return (
    <AppBackground title={'Create A Request'}>
      <View style={{flex: 1, paddingHorizontal: 20}}>
        <TextWithActionSheet
          icon={Icons.pin}
          placeholder="City"
          value={city}
          onSelect={text => setCity(text)}
          dataset={cities}
        />
        <CustomTextInput
          icon={Icons.city}
          value={hospital}
          onChangeText={text => setHospital(text)}
          placeholder={'Hospital'}
        />
        <TextWithActionSheet
          icon={Icons.bloodDrop}
          placeholder="Blood Group"
          value={bloodGroup}
          onSelect={text => setBloodGroup(text)}
          dataset={bloodGroups}
        />
        <CustomTextInput
          icon={Icons.phone}
          value={mobile}
          onChangeText={text => setMobile(text)}
          placeholder={'Mobile Number'}
          keyboardType="phone-pad"
          maxLength={13}
        />
        <CustomTextInput
          icon={Icons.note}
          value={note}
          onChangeText={text => setNote(text)}
          placeholder={'Note'}
          multiline
          inputStyle={{textAlignVertical: 'top'}}
          containerStyle={{
            width: '100%',
            height: 100,
            justifyContent: 'flex-start',
            alignItems: 'flex-start',
          }}
        />
        <CustomButton
      title={'Request'}
      onPress={() =>
        requestDonation(
          city,
          hospital,
          bloodGroup,
          mobile,
          note,
          userData?.phone,
          userData?.name,
          latitude,
          longitude,
        )
      }
    />
      </View>
    </AppBackground>
  );
};

export default RequestBlood;
